from io import open
from setuptools import setup

"""
:authors: EasyOmny
:license: #
:copyright: (c) 2023 EasyOmny
"""

version = '0.0.1'

with open('README.md', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='kkScrip',
    version=version,

    author='EasyOmny',
    author_email='omenplay325@gmail.com',

    description=(
        u'Simple database with programming language.'
    ),

    long_description=long_description,
    long_description_content_type='text/markdown',

    url='https://github.com/EasyOmny/kkscript',
    download_url=''

)